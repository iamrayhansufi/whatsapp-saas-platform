"use client";
import { useSession } from "next-auth/react";
import { useState } from "react";
import { Button, Input, Card, CardHeader, CardTitle, CardContent } from "../../components/ui";

export default function MessagesPage() {
  const { data: session } = useSession();
  const [to, setTo] = useState("");
  const [message, setMessage] = useState("");
  const [waNumberId, setWaNumberId] = useState("");
  const [status, setStatus] = useState("");

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    setStatus("Sending...");
    const res = await fetch("/api/whatsapp/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ to, message, waNumberId }),
    });
    const data = await res.json();
    if (data.success) setStatus("Message sent!");
    else setStatus(data.error || "Failed");
  }

  if (!session) return <div>Unauthorized</div>;
  // For demo, set waNumberId directly or fetch/manage numbers as needed

  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Card className="w-[400px]">
        <CardHeader>
          <CardTitle>Send WhatsApp Message</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSend} className="space-y-3">
            <Input placeholder="Recipient Number" value={to} onChange={e => setTo(e.target.value)} required />
            <Input placeholder="Message" value={message} onChange={e => setMessage(e.target.value)} required />
            <Input placeholder="WhatsApp Number ID" value={waNumberId} onChange={e => setWaNumberId(e.target.value)} required />
            <Button type="submit" className="w-full">Send</Button>
          </form>
          {status && <div className="mt-2 text-sm">{status}</div>}
        </CardContent>
      </Card>
    </div>
  );
}