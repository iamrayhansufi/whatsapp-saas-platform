"use client";
import { useSession } from "next-auth/react";
import { Button } from "../../components/ui/button";
import Link from "next/link";

export default function Dashboard() {
  const { data: session, status } = useSession();

  if (status === "loading") return <div>Loading...</div>;
  if (!session) return <div>Unauthorized</div>;

  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold mb-2">Welcome, {session.user.email}</h1>
      <p className="mb-4 text-gray-500">Tenant: {session.user.tenantId}</p>
      <div className="flex gap-4">
        <Button asChild>
          <Link href="/dashboard/messages">Send WhatsApp Message</Link>
        </Button>
        <Button asChild>
          <Link href="/dashboard/numbers">Manage Numbers</Link>
        </Button>
      </div>
    </main>
  );
}