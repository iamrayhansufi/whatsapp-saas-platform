import type { NextApiRequest, NextApiResponse } from "next";
import { getServerSession } from "next-auth";
import { authOptions } from "../auth/[...nextauth]";
import { sendWhatsAppMessage } from "../../../lib/whatsapp";
import { prisma } from "../../../lib/prisma";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const session = await getServerSession(req, res, authOptions);
  if (!session) return res.status(401).json({ error: "Unauthorized" });

  const { to, message, waNumberId } = req.body;
  if (!to || !message || !waNumberId) return res.status(400).json({ error: "Missing fields" });

  const waNumber = await prisma.whatsAppNumber.findUnique({
    where: { id: waNumberId, tenantId: session.user.tenantId },
  });
  if (!waNumber) return res.status(404).json({ error: "WhatsApp number not found" });

  try {
    await sendWhatsAppMessage(waNumber.apiToken, waNumber.phoneNumberId, to, message);
    await prisma.message.create({
      data: {
        content: message,
        sender: waNumber.number,
        recipient: to,
        status: "sent",
        waNumberId: waNumber.id,
      },
    });
    res.status(200).json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to send message" });
  }
}