import { ReactNode } from "react";
import { cn } from "../../lib/utils";

export function Card({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("bg-white shadow rounded-lg", className)} {...props} />;
}

export function CardHeader({ children, className, ...props }: { children: ReactNode } & React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("p-4 border-b border-gray-200", className)} {...props}>
      {children}
    </div>
  );
}

export function CardTitle({ children, className, ...props }: { children: ReactNode } & React.HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h2 className={cn("text-lg font-semibold", className)} {...props}>
      {children}
    </h2>
  );
}

export function CardContent({ children, className, ...props }: { children: ReactNode } & React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("p-4", className)} {...props}>
      {children}
    </div>
  );
}