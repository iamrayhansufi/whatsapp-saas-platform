import axios from "axios";

export async function sendWhatsAppMessage(apiToken: string, phoneNumberId: string, to: string, message: string) {
  const url = `https://graph.facebook.com/v19.0/${phoneNumberId}/messages`;
  const payload = {
    messaging_product: "whatsapp",
    to,
    type: "text",
    text: { body: message },
  };

  await axios.post(url, payload, {
    headers: {
      Authorization: `Bearer ${apiToken}`,
      "Content-Type": "application/json",
    },
  });
}